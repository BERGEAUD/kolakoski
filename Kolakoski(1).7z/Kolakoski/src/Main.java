
import java.io.*;


public class Main {

	private  float[] tabGraphe;

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int xMax = 1000;
		int x1 = 1;
		int x2 = 2;
		int i=0;
		int z = 1; //Pour le faire commencer en deuxi�me position
		int j;
		int tab[] = new int[xMax];
		final String chemin = "C:'\'Users'\'Etudiant";
        final File fichier = new File(chemin); 
		
		float tabGaphe[]= new float[xMax]; // pour faire le graphe
		
		int nbDeux = 0;
		
		for(j=0; j< x2; j++){
			tab[i]= x2;
			System.out.print(tab[i]);
			nbDeux ++;
			i++;
			tabGaphe[i] = (float) nbDeux/i; // on prend nbDeux comme �a pas de cas avec division par 0.
		}
		
		while (i < (xMax - x2)){
			if(tab[i-1] == x1){
				for(j=0; j< tab[z]; j++){
					tab[i] = x2;
					System.out.print(tab[i]);
					nbDeux ++;
					i++;
					tabGaphe[i] = (float) nbDeux/i;
				}
			}
			else{
				for(j=0; j< tab[z]; j++){
					tab[i] = x1;
					System.out.print(tab[i]);
					i++;
					tabGaphe[i] = (float) nbDeux/i;
				}
			}
			z++; //lecture			
		}
		
		System.out.println();
		System.out.println("Nb deux : " + nbDeux);
		System.out.println("Nb un : " + (i-nbDeux));
		
		
		
		try {
            // Creation du fichier
            fichier .createNewFile();
            // creation d'un writer (un �crivain)
            final FileWriter writer = new FileWriter(fichier);
            try {
                for (i=0; i< xMax; i++){
        			writer.write(tab[i]);
        		}
                System.out.println("caca");
            } finally {
                // quoiqu'il arrive, on ferme le fichier
                writer.close();
            }
        } catch (Exception e) {
            System.out.println("Impossible de creer le fichier");
        }
	}
}

